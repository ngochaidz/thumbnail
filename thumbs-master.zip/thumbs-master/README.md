# Materia Tools
- HTML Formatter Tool;
- Syntax Highlighter Tool;
- Thumbnail Generator.

# Credits
- [jQuery](https://github.com/jquery/jquery);
- [canvas2image](https://github.com/hongru/canvas2image);
- [highlight.js](https://github.com/highlightjs/highlight.js);
- [Materialize](https://github.com/Dogfalo/materialize).

Copyright © Yasya El Hakim - <a href="https://www.elcreativeacademy.com/" target="_blank" alt="EL Creative Academy">EL Creative Academy</a>   
